#!/usr/bin/env sh
# BootX CLI Tool
# Launch script
#
# author: maoba@dtstack.com

DIR=`cd "\`dirname "$0"\`" && pwd`

if [ -z "$JAVA" ] ; then
  JAVA=$(which java)
fi

if [ -z "$JAVA" ]; then
    echo "[Pre-Requirement] - Cannot find a Java JDK. Please set either set JAVA or put java (>=1.8) in your PATH." 2>&2
    exit 1
fi

"$JAVA" $JAVA_OPTS -cp "$DIR/bootx-cli.jar:$TOOLSJAR" \
com.dtstack.plat.bootx.cli.BootXCLI "$@"
exit $?